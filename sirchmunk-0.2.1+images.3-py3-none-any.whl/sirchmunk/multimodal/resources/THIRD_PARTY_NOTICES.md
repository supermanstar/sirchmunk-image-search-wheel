# Third-party dependencies and local modifications

Sirchmunk source: https://github.com/modelscope/sirchmunk

Development checkout: `third_party/sirchmunk`

Base commit: `b314e11fcea87cf8146b2844cf2f991208c021d9`

Base version: `0.2.1+main`; local modified version: `0.2.1+images.3`.

License: Apache License 2.0, retained in the Sirchmunk distribution. Local modifications on 2026-10-08 add `sirchmunk.multimodal`, native SDK exports, optional image dependencies, a file-search CLI, configuration, tests, documentation and a Kreuzberg text-extraction API compatibility fix. The 2026-10-09 update adds multi-file SDK/HTTP retrieval and source-scoped image references. The existing `AgenticSearch` algorithm implementation is retained. This is a local derivative, not an upstream release.

The modified Sirchmunk wheel includes its file/image implementation and does not depend on the wrapper. The former wrapper compatibility source and distributions were removed from this workspace on 2026-10-09. Use the modified native Sirchmunk distribution rather than the unmodified base Git commit.

PDF rendering uses pypdfium2, distributed under Apache-2.0/BSD-3-Clause as recorded in its installed package metadata; PDFium and bundled third-party notices are supplied with the dependency. Other dependencies retain their own license terms and notices. This file identifies dependencies; it does not replace their license files.
