# Local derivative, 2026-10-08: native file/image retrieval extension.
__version__ = "0.2.1+images.4"
