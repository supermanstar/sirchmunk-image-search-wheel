class FileSearchError(Exception):
    """Public error with a stable code and safe, user-facing message."""

    def __init__(self, code: str, message: str, status: int = 400):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)



# Keep existing exception handlers compatible.
WrapError = FileSearchError
