from pathlib import Path
from typing import Literal
from pydantic import AliasChoices, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

MODEL_FIELDS = frozenset({
    "text_base_url", "text_api_key", "text_model",
    "vision_base_url", "vision_api_key", "vision_model",
})


def _model_source(source):
    """Environment/config files may supply model settings only."""
    allowed = set(MODEL_FIELDS)
    for name in MODEL_FIELDS:
        allowed.update(_env(name).choices)

    def read():
        return {key: value for key, value in source().items() if key in allowed}

    return read


def _env(name):
    return AliasChoices("SIRCHMUNK_" + name.upper(), "WRAP_" + name.upper())


class FileSearchSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SIRCHMUNK_", env_file=".env", extra="ignore", populate_by_name=True)
    data_dir: Path = Field(Path("data"), validation_alias=_env("data_dir"))
    image_cache_dir: Path | None = Field(None, validation_alias=_env("image_cache_dir"))
    text_base_url: str = Field("", validation_alias=_env("text_base_url"))
    text_api_key: SecretStr = Field(SecretStr(""), validation_alias=_env("text_api_key"))
    text_model: str = Field("", validation_alias=_env("text_model"))
    vision_base_url: str = Field("", validation_alias=_env("vision_base_url"))
    vision_api_key: SecretStr = Field(SecretStr(""), validation_alias=_env("vision_api_key"))
    vision_model: str = Field("", validation_alias=_env("vision_model"))
    service_token: SecretStr = Field(SecretStr(""), validation_alias=_env("service_token"))
    model_timeout_seconds: float = Field(60, gt=0, validation_alias=_env("model_timeout_seconds"))
    request_timeout_seconds: float = Field(180, gt=0, validation_alias=_env("request_timeout_seconds"))
    vision_concurrency: int = Field(2, ge=1, le=32, validation_alias=_env("vision_concurrency"))
    max_candidates: int = Field(10, ge=1, le=100, description="Sirchmunk 初始文件检索数量，不限制图片复核或返回数量。", validation_alias=_env("max_candidates"))
    max_upload_mb: int = Field(50, ge=1, validation_alias=_env("max_upload_mb"))
    max_uncompressed_mb: int = Field(200, ge=1, validation_alias=_env("max_uncompressed_mb"))
    max_pixels: int = Field(40_000_000, ge=1, validation_alias=_env("max_pixels"))
    max_pages: int = Field(1000, ge=1, validation_alias=_env("max_pages"))
    max_images: int = Field(500, ge=1, validation_alias=_env("max_images"))
    max_query_chars: int = Field(10000, ge=1, validation_alias=_env("max_query_chars"))
    max_model_retries: int = Field(2, ge=0, le=5, validation_alias=_env("max_model_retries"))
    max_token_budget: int = Field(64000, ge=1000, validation_alias=_env("max_token_budget"))
    search_mode: Literal["FAST", "DEEP"] = Field("DEEP", validation_alias=_env("search_mode"))

    @classmethod
    def settings_customise_sources(cls, settings_cls, init_settings, env_settings,
                                  dotenv_settings, file_secret_settings):
        return (init_settings, _model_source(env_settings), _model_source(dotenv_settings))

    @classmethod
    def from_parameters(cls, **parameters):
        """Use explicit arguments/defaults without .env or environment lookup."""
        unknown = set(parameters) - set(cls.model_fields)
        if unknown:
            raise TypeError("Unknown file search parameters: " + ", ".join(sorted(unknown)))
        return _ParameterSettings(**parameters)

    def resolve_storage_paths(self, base_dir: Path | None = None):
        base = (base_dir or Path.cwd()).resolve()
        data = self.data_dir if self.data_dir.is_absolute() else base / self.data_dir
        images = self.image_cache_dir
        if images is None:
            images = data / "image_cache"
        elif not images.is_absolute():
            images = base / images
        return self.model_copy(update={"data_dir": data.resolve(), "image_cache_dir": images.resolve()})



Settings = FileSearchSettings


class _ParameterSettings(FileSearchSettings):
    """Parameter-only configuration for library callers."""
    model_config = SettingsConfigDict(env_file=None)

    @classmethod
    def settings_customise_sources(cls, settings_cls, init_settings, env_settings,
                                  dotenv_settings, file_secret_settings):
        return (init_settings,)
