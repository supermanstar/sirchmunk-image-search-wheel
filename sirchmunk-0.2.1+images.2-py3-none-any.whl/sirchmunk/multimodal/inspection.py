"""Local structural inspection; this module never calls a model."""
import base64
import io
import posixpath
import zipfile
import threading
from pathlib import Path
from xml.etree import ElementTree as ET

from charset_normalizer import from_bytes
from PIL import Image
from .errors import WrapError
from .models import ExtractedImage, Inspection
from .settings import Settings

SUPPORTED = {".txt", ".md", ".pdf", ".docx", ".pptx", ".png", ".jpg", ".jpeg"}
EXTRACTOR_VERSION = "file-extractor-v3"
NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "v": "urn:schemas-microsoft-com:vml",
}
PDF_RENDER_LOCK = threading.Lock()


def normalized_png_bytes(image: Image.Image) -> bytes:
    """Build the vision/cache representation without storing another image."""
    if "A" in image.getbands() or "transparency" in image.info:
        normalized = Image.new("RGB", image.size, "white")
        rgba = image.convert("RGBA")
        normalized.paste(rgba, mask=rgba.getchannel("A"))
    else:
        normalized = image.convert("RGB")
    output = io.BytesIO()
    normalized.save(output, "PNG")
    return output.getvalue()


class Inspector:
    def __init__(self, settings: Settings):
        self.settings = settings

    def _image(self, data: bytes, folder: Path, result: Inspection, **location):
        if len(result.images) >= self.settings.max_images:
            raise WrapError("FILE_LIMIT_EXCEEDED", "图片数量超出配置上限。", 413)
        try:
            with Image.open(io.BytesIO(data)) as image:
                if image.width * image.height > self.settings.max_pixels:
                    raise WrapError("IMAGE_TOO_LARGE", "图片解码后的像素数超出配置上限。", 413)
                image.load()
                image_id = f"img_{len(result.images) + 1:04d}"
                image_format = image.format
                original = None
                mime_type = "image/png"
                if image_format in {"PNG", "JPEG"}:
                    extension = ".jpg" if image_format == "JPEG" else ".png"
                    output = folder / (image_id + extension)
                    output.write_bytes(data)
                    original = output
                    mime_type = "image/jpeg" if image_format == "JPEG" else "image/png"
                else:
                    output = folder / (image_id + ".png")
                    output.write_bytes(normalized_png_bytes(image))
        except WrapError:
            raise
        except Exception as exc:
            raise WrapError("FILE_INSPECTION_FAILED", "检测到图片，但无法解码。") from exc
        result.images.append(ExtractedImage(path=output, original_path=original, mime_type=mime_type, **location))

    def inspect(self, file: Path, images_folder: Path, original_name: str):
        suffix = Path(original_name).suffix.lower()
        if suffix not in SUPPORTED:
            raise WrapError("UNSUPPORTED_MEDIA", "不支持该文件类型。支持 TXT/MD/PDF/DOCX/PPTX/JPEG/PNG。", 415)
        images_folder.mkdir(parents=True, exist_ok=True)
        try:
            if suffix in {".txt", ".md"}:
                return self._text(file, images_folder, suffix)
            if suffix in {".jpg", ".jpeg", ".png"}:
                result = Inspection("")
                self._image(file.read_bytes(), images_folder, result)
                return result
            if suffix == ".pdf":
                return self._pdf(file, images_folder)
            self._check_zip(file)
            if suffix == ".docx":
                return self._docx(file, images_folder)
            return self._pptx(file, images_folder)
        except WrapError:
            raise
        except Exception as exc:
            raise WrapError("FILE_INSPECTION_FAILED", "文件结构损坏、加密或解析失败。") from exc

    def _check_zip(self, file):
        with zipfile.ZipFile(file) as archive:
            if sum(entry.file_size for entry in archive.infolist()) > self.settings.max_uncompressed_mb * 1024**2:
                raise WrapError("FILE_LIMIT_EXCEEDED", "文档解压大小超出配置上限。", 413)

    def _text(self, file, folder, suffix):
        data = file.read_bytes()
        if b"\x00" in data and not data.startswith((b"\xff\xfe", b"\xfe\xff")):
            raise WrapError("FILE_INSPECTION_FAILED", "文件包含二进制内容，不能作为纯文本读取。")
        match = from_bytes(data).best()
        if match is None and data:
            raise WrapError("FILE_INSPECTION_FAILED", "无法识别文本编码。")
        result = Inspection(str(match) if match is not None else "")
        if suffix == ".md":
            from markdown_it import MarkdownIt
            for token in MarkdownIt().parse(result.text):
                for child in token.children or []:
                    if child.type != "image":
                        continue
                    result.referenced_images += 1
                    target = child.attrGet("src") or ""
                    if target.startswith("data:image/") and ";base64," in target:
                        try:
                            decoded = base64.b64decode(target.split(",", 1)[1], validate=True)
                        except ValueError as exc:
                            raise WrapError("FILE_INSPECTION_FAILED", "Markdown 内嵌图片编码无效。") from exc
                        self._image(decoded, folder, result, context=child.content)
                    else:
                        result.complete = False
                        result.warnings.append("Markdown 引用了未随单文件提交的图片；未读取本地外部路径或抓取链接。")
        return result

    def _docx(self, file, folder):
        result = Inspection("")
        parts = []
        with zipfile.ZipFile(file) as archive:
            names = set(archive.namelist())
            styles = {}
            if "word/styles.xml" in names:
                styles = {style.attrib.get(f"{{{NS['w']}}}styleId"): style
                          for style in ET.fromstring(archive.read("word/styles.xml")).findall("w:style", NS)}

            def outline_level(paragraph):
                level = paragraph.find("w:pPr/w:outlineLvl", NS)
                style_ref = paragraph.find("w:pPr/w:pStyle", NS)
                style_id = style_ref.attrib.get(f"{{{NS['w']}}}val") if style_ref is not None else None
                seen = set()
                while level is None and style_id in styles and style_id not in seen:
                    seen.add(style_id)
                    style = styles[style_id]
                    level = style.find("w:pPr/w:outlineLvl", NS)
                    parent = style.find("w:basedOn", NS)
                    style_id = parent.attrib.get(f"{{{NS['w']}}}val") if parent is not None else None
                if level is not None:
                    value = level.attrib.get(f"{{{NS['w']}}}val", "")
                    if value.isdigit() and 0 <= int(value) <= 8:
                        return int(value)
                return None

            # Main document and its referenced header/footer/notes only.
            selected = ["word/document.xml"]
            rel_main = "word/_rels/document.xml.rels"
            if rel_main in names:
                for rel in ET.fromstring(archive.read(rel_main)):
                    if rel.attrib.get("TargetMode") != "External" and rel.attrib.get("Type", "").rsplit("/", 1)[-1] in {"header", "footer", "footnotes", "endnotes"}:
                        selected.append(posixpath.normpath(posixpath.join("word", rel.attrib["Target"])))
            for part in dict.fromkeys(selected):
                xml = ET.fromstring(archive.read(part))
                headings, preceding = [], []
                section_texts = {}
                first_image = len(result.images)
                relationships = {}
                relfile = posixpath.join(posixpath.dirname(part), "_rels", posixpath.basename(part) + ".rels")
                if relfile in names:
                    relationships = {r.attrib["Id"]: r.attrib for r in ET.fromstring(archive.read(relfile))}
                for number, paragraph in enumerate(xml.findall(".//w:p", NS), 1):
                    text = "".join(node.text or "" for node in paragraph.findall(".//w:t", NS))
                    parts.append(text)
                    level = outline_level(paragraph)
                    if level is not None and text.strip():
                        headings = [heading for heading in headings if heading[0] < level]
                        headings.append((level, text.strip(), f"{part}:heading:{number}"))
                        preceding = []
                    section_id = headings[-1][2] if headings else ""
                    section_title = " > ".join(heading[1] for heading in headings)
                    if section_id and text.strip():
                        section_texts.setdefault(section_id, []).append(text)
                    context_parts = []
                    if headings:
                        context_parts.append("章节：" + section_title)
                    context_parts.extend(preceding[-4:])
                    if text.strip():
                        context_parts.append(text)
                    context = "\n".join(context_parts)[:4000]
                    refs = []
                    for node in paragraph.findall(".//a:blip", NS):
                        refs.append(node.attrib.get(f"{{{NS['r']}}}embed") or node.attrib.get(f"{{{NS['r']}}}link"))
                    for node in paragraph.findall(".//v:imagedata", NS):
                        refs.append(node.attrib.get(f"{{{NS['r']}}}id"))
                    for reference in refs:
                        result.referenced_images += 1
                        rel = relationships.get(reference, {})
                        target = posixpath.normpath(posixpath.join(posixpath.dirname(part), rel.get("Target", "")))
                        if rel.get("TargetMode") == "External" or target not in names:
                            result.complete = False
                            result.warnings.append("DOCX 含无法读取的外链或缺失图片。")
                            continue
                        self._image(archive.read(target), folder, result, context=context,
                                    section_id=section_id, section_title=section_title,
                                    anchor=f"{posixpath.basename(part)}:paragraph:{number}")
                    # Drawing without a raster image is outside the first implementation.
                    if not refs and (paragraph.find(".//w:drawing", NS) is not None or paragraph.find(".//w:pict", NS) is not None):
                        result.complete = False
                        result.warnings.append("DOCX 含尚未渲染的非位图绘图对象，检测不完整。")
                    if text.strip():
                        preceding.append(text[:1000])
                        preceding = preceding[-4:]
                # A workflow's early navigation pictures also need the later
                # operation steps, while sibling workflows remain separate.
                for image in result.images[first_image:]:
                    image.section_text = "\n".join(section_texts.get(image.section_id, []))[:12000]
        result.text = "\n".join(parts)
        return result

    def _pptx(self, file, folder):
        from pptx import Presentation
        from pptx.enum.shapes import MSO_SHAPE_TYPE
        presentation = Presentation(file)
        if len(presentation.slides) > self.settings.max_pages:
            raise WrapError("FILE_LIMIT_EXCEEDED", "幻灯片数量超出配置上限。", 413)
        result = Inspection("")
        parts = []

        def walk(shapes):
            for shape in shapes:
                if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
                    yield from walk(shape.shapes)
                else:
                    yield shape

        for number, slide in enumerate(presentation.slides, 1):
            shapes = list(walk(slide.shapes))
            text = "\n".join(shape.text for shape in shapes if shape.has_text_frame)
            parts.append(f"[Slide {number}]\n{text}")
            for shape in shapes:
                if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                    result.referenced_images += 1
                    self._image(shape.image.blob, folder, result, context=text[:4000], slide=number,
                                anchor=f"shape:{shape.shape_id}")
                elif shape.has_table:
                    parts.append("\n".join("\t".join(cell.text for cell in row.cells) for row in shape.table.rows))
                elif shape.shape_type not in {MSO_SHAPE_TYPE.TEXT_BOX, MSO_SHAPE_TYPE.PLACEHOLDER}:
                    result.complete = False
                    result.warnings.append(f"第 {number} 页含未渲染的绘图/图表对象，检测不完整。")
            # Background picture fills and linked images need explicit acknowledgement.
            if slide._element.xpath(".//a:blip") and not any(s.shape_type == MSO_SHAPE_TYPE.PICTURE for s in shapes):
                result.complete = False
                result.referenced_images += 1
                result.warnings.append(f"第 {number} 页含尚未提取的图片填充。")
        result.text = "\n".join(parts)
        return result

    def _pdf(self, file, folder):
        from pypdf import PdfReader
        from pypdf.generic import ContentStream
        reader = PdfReader(file)
        if reader.is_encrypted:
            raise WrapError("FILE_INSPECTION_FAILED", "PDF 已加密，请先解锁。")
        if len(reader.pages) > self.settings.max_pages:
            raise WrapError("FILE_LIMIT_EXCEEDED", "PDF 页数超出配置上限。", 413)
        result = Inspection("")
        parts = []

        def used_images(stream, resources, prefix=(), visited=None):
            found, vector = set(), False
            visited = set() if visited is None else visited
            if stream is None:
                return found, vector
            if hasattr(resources, "get_object"):
                resources = resources.get_object()
            xobjects = resources.get("/XObject", {}).get_object() if resources.get("/XObject") else {}
            for operands, op in ContentStream(stream, reader).operations:
                if op == b"INLINE IMAGE":
                    found.add(prefix + ("INLINE",))
                elif op == b"Do" and operands:
                    name = operands[0]
                    obj = xobjects.get(name)
                    if obj is None:
                        continue
                    obj = obj.get_object()
                    if obj.get("/Subtype") == "/Image":
                        found.add(prefix + (str(name),))
                    elif obj.get("/Subtype") == "/Form" and id(obj) not in visited:
                        visited.add(id(obj))
                        sub, drawing = used_images(obj, obj.get("/Resources", resources), prefix + (str(name),), visited)
                        found.update(sub)
                        vector = vector or drawing
                elif op in {b"S", b"s", b"f", b"F", b"f*", b"B", b"B*", b"b", b"b*"}:
                    vector = True
            return found, vector

        for number, page in enumerate(reader.pages, 1):
            text = page.extract_text() or ""
            parts.append(f"[Page {number}]\n{text}" if text.strip() else "")
            used, drawing = used_images(page.get_contents(), page.get("/Resources", {}))
            if used and not text.strip():
                # A scanned page is returned as one page image, retaining its original layout.
                import pypdfium2 as pdfium
                with PDF_RENDER_LOCK, pdfium.PdfDocument(file) as document:
                    pdfpage = document[number - 1]
                    try:
                        width, height = pdfpage.get_size()
                        scale = min(2.0, (self.settings.max_pixels / max(width * height, 1)) ** 0.5)
                        bitmap = pdfpage.render(scale=scale)
                        try:
                            buffer = io.BytesIO()
                            bitmap.to_pil().save(buffer, "PNG")
                        finally:
                            bitmap.close()
                        self._image(buffer.getvalue(), folder, result, page=number, anchor="scanned_page")
                    finally:
                        pdfpage.close()
            elif used:
                for key in page.images.keys():
                    tokens = tuple(key) if isinstance(key, list) else (str(key),)
                    inline = tokens[-1].startswith("~") and any(u[-1] == "INLINE" for u in used)
                    if tokens not in used and not inline:
                        continue
                    image = page.images[key]
                    self._image(image.data, folder, result, context=text[:4000], page=number)
            if drawing:
                result.complete = False
                result.warnings.append(f"PDF 第 {number} 页含矢量绘图，当前仅提取位图和正文。")
            if used and not any(image.page == number for image in result.images):
                result.complete = False
                result.referenced_images += 1
                result.warnings.append(f"PDF 第 {number} 页检测到图片但未成功提取。")
        result.text = "\n".join(parts)
        return result

