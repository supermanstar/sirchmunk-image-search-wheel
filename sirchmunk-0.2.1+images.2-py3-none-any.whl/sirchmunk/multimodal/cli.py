import argparse
import importlib.util
import shutil
import sys
from pathlib import Path
from importlib.resources import files
from .settings import Settings


def main():
    parser = argparse.ArgumentParser(description="sirchmunk-files API service")
    subs = parser.add_subparsers(dest="command", required=True)
    serve = subs.add_parser("serve", help="Start the HTTP API")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8585)
    serve.add_argument("--service-token", required=True, help="HTTP Bearer token (separate from model API keys)")
    serve.add_argument("--data-dir", type=Path, default=argparse.SUPPRESS)
    serve.add_argument("--image-cache-dir", type=Path, default=argparse.SUPPRESS)
    serve.add_argument("--search-mode", choices=["FAST", "DEEP"], default=argparse.SUPPRESS)
    for name in ("model_timeout_seconds", "request_timeout_seconds"):
        serve.add_argument("--" + name.replace("_", "-"), type=float, default=argparse.SUPPRESS)
    for name in ("vision_concurrency", "max_candidates", "max_upload_mb", "max_uncompressed_mb",
                 "max_pixels", "max_pages", "max_images", "max_query_chars", "max_model_retries", "max_token_budget"):
        serve.add_argument("--" + name.replace("_", "-"), type=int, default=argparse.SUPPRESS)
    subs.add_parser("doctor", help="Check local dependencies without model requests")
    subs.add_parser("init", help="Create a local configuration template without overwriting existing settings")
    args = parser.parse_args()
    configuration = {key: value for key, value in vars(args).items() if key in Settings.model_fields}
    settings = Settings(**configuration)
    if args.command == "init":
        path = Path(".env")
        if path.exists():
            print(".env already exists; kept existing configuration.")
            return
        template = files("sirchmunk.multimodal").joinpath("resources/env.example").read_text(encoding="utf-8")
        # Exclusive creation also protects against another process creating the file.
        with path.open("x", encoding="utf-8") as output:
            output.write(template)
        print("Created .env. Configure your text and vision models before use.")
    elif args.command == "serve":
        if not settings.service_token.get_secret_value():
            parser.error("HTTP 服务需要传入非空 --service-token。")
        import uvicorn
        from .api import create_app
        uvicorn.run(create_app(settings), host=args.host, port=args.port, workers=1)
    else:
        print("Python:", sys.version.split()[0])
        print("Sirchmunk installed:", importlib.util.find_spec("sirchmunk") is not None)
        print("rg:", shutil.which("rg") or "not on PATH (upstream may use its tool cache)")
        print("rga:", shutil.which("rga") or "not on PATH (upstream may use its tool cache)")
        print("Text model configured:", bool(settings.text_base_url and settings.text_model))
        print("Vision model configured:", bool(settings.vision_base_url and settings.vision_model))


if __name__ == "__main__":
    main()

