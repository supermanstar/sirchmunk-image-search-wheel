"""Small persistent catalogue; one SQLite connection per transaction."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from .errors import WrapError


class Catalog:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.database = self.root / "catalog.sqlite"
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS sources (id TEXT PRIMARY KEY, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS cache (id TEXT PRIMARY KEY, body TEXT NOT NULL);
            """)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.database, timeout=30)
        try:
            with db:
                yield db
        finally:
            db.close()

    def put(self, table: str, identifier: str, body: dict):
        assert table in {"sources", "jobs", "cache"}
        with self.connect() as db:
            db.execute(f"INSERT OR REPLACE INTO {table} VALUES (?, ?)",
                       (identifier, json.dumps(body, ensure_ascii=False)))

    def get(self, table: str, identifier: str):
        assert table in {"sources", "jobs", "cache"}
        with self.connect() as db:
            row = db.execute(f"SELECT body FROM {table} WHERE id = ?", (identifier,)).fetchone()
        return json.loads(row[0]) if row else None

    def delete(self, table: str, identifier: str):
        assert table in {"sources", "jobs", "cache"}
        with self.connect() as db:
            db.execute(f"DELETE FROM {table} WHERE id = ?", (identifier,))

    def submit(self, source_id: str, source: dict, job_id: str, job: dict):
        with self.connect() as db:
            db.execute("INSERT INTO sources VALUES (?, ?)", (source_id, json.dumps(source, ensure_ascii=False)))
            db.execute("INSERT INTO jobs VALUES (?, ?)", (job_id, json.dumps(job, ensure_ascii=False)))

    def all(self, table: str):
        assert table in {"sources", "jobs", "cache"}
        with self.connect() as db:
            rows = db.execute(f"SELECT body FROM {table}").fetchall()
        return [json.loads(row[0]) for row in rows]

    def source(self, source_id: str):
        record = self.get("sources", source_id)
        if not record or record["info"]["status"] == "deleted":
            raise WrapError("SOURCE_NOT_FOUND", "文件不存在或已删除。", 404)
        return record

    def path(self, key: str):
        resolved = (self.root / key).resolve()
        if not resolved.is_relative_to(self.root):
            raise WrapError("INVALID_STORAGE_PATH", "文件路径超出受管目录。", 400)
        return resolved

