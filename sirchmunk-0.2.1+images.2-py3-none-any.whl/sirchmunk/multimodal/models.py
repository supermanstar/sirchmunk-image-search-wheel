from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FileInfo(Model):
    source_id: str
    file_name: str
    status: Literal["pending", "processing", "ready", "failed", "deleted"]
    content_kind: Literal["text_only", "mixed", "image_only", "unknown"] = "unknown"
    has_images: bool | None = None
    image_count: int = 0
    detection_complete: bool = False
    warnings: list[str] = Field(default_factory=list)
    error: dict | None = None


class Submission(Model):
    source_id: str
    job_id: str


class JobInfo(Model):
    job_id: str
    source_id: str
    status: Literal["pending", "processing", "completed", "failed", "cancelled"]
    processed_images: int = 0
    total_images: int = 0
    error: dict | None = None


class ImageSource(Model):
    source_id: str
    file_name: str
    page: int | None = None
    slide: int | None = None
    anchor: str | None = None


class ImageResult(Model):
    image_id: str
    reference_id: str = Field(description="跨文件唯一引用，格式为 source_id:image_id。")
    caption: str
    path: str = Field(description="缓存原图片在服务运行机器上的绝对文件路径。")
    url: str
    mime_type: str = "image/png"
    verification_status: Literal["verified", "unverified"]
    source: ImageSource


class SearchResult(Model):
    request_id: str
    answer: str
    images: list[ImageResult] = Field(default_factory=list)
    sources: list[dict] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class VisionDescription(Model):
    caption: str = Field(min_length=1, max_length=10000)
    ocr_text: str = Field(default="", max_length=50000)
    tags: list[str] = Field(default_factory=list, max_length=50)


class Verification(Model):
    relevant: bool
    reason: str = Field(default="", max_length=3000)


@dataclass
class ExtractedImage:
    path: Path
    original_path: Path | None = None
    mime_type: str = "image/png"
    context: str = ""
    page: int | None = None
    slide: int | None = None
    anchor: str | None = None
    section_id: str = ""
    section_title: str = ""
    section_text: str = ""


@dataclass
class Inspection:
    text: str
    images: list[ExtractedImage] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    complete: bool = True
    referenced_images: int = 0

    @property
    def content_kind(self):
        if not self.complete and not self.images:
            return "unknown"
        if self.images:
            return "mixed" if self.text.strip() else "image_only"
        return "text_only"

    @property
    def has_images(self):
        if self.images or self.referenced_images:
            return True
        return False if self.complete else None



@dataclass
class Evidence:
    path: Path
    summary: str = ""
    source_label: str = ""


@dataclass
class Retrieval:
    answer: str
    evidences: list[Evidence]

