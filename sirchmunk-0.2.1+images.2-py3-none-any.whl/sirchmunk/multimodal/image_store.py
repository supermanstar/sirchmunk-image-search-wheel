"""Stable image files in a separately configured cache directory."""
import shutil
import uuid
from pathlib import Path
from .errors import WrapError


def cache_path(root: Path, key: str):
    root = root.resolve()
    path = (root / key).resolve()
    if path == root or not path.is_relative_to(root):
        raise WrapError("INVALID_STORAGE_PATH", "图片路径超出缓存目录。")
    return path


class ImageStore:
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def path(self, key):
        return cache_path(self.root, key)

    def _remove(self, folder):
        target = cache_path(self.root, str(folder))
        if target.exists():
            shutil.rmtree(target)

    def install(self, source_id: str, files: list[Path]):
        """Commit all images once; never called for an ordinary cache hit."""
        target = self.path(source_id)
        temporary = self.path(f".staging_{source_id}_{uuid.uuid4().hex}")
        temporary.mkdir()
        try:
            for file in dict.fromkeys(files):
                if not file.is_file():
                    raise WrapError("IMAGE_CACHE_MISSING", "缓存图片缺失，请重新提交原文件。", 409)
                shutil.copy2(file, temporary / file.name)
            self._remove(target)
            temporary.replace(target)
        finally:
            self._remove(temporary)

    def delete_source(self, source_id):
        self._remove(self.path(source_id))
