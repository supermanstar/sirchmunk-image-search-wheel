import secrets
import uuid
from contextlib import asynccontextmanager
from typing import Literal
from fastapi import FastAPI, Depends, File, UploadFile, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import Field, model_validator
from .errors import WrapError
from .models import Model, FileInfo, JobInfo, Submission, SearchResult
from .sdk import Client
from .settings import Settings
from ..version import __version__


class SearchRequest(Model):
    source_id: str | None = Field(default=None, min_length=1, max_length=100)
    source_ids: list[str] | None = Field(default=None, min_length=1, max_length=100)
    query: str = Field(min_length=1)
    types: list[Literal["text", "image"]] = Field(default_factory=lambda: ["text", "image"])
    image_limit: int | None = Field(default=None, ge=0,
        description="省略或 null 时返回全部匹配图片；非负整数可显式限制数量，0 表示不返回图片。")
    verify_images: bool = True

    @model_validator(mode="after")
    def one_source_scope(self):
        if (self.source_id is None) == (self.source_ids is None):
            raise ValueError("必须提供 source_id 或 source_ids，且只能提供其中一个。")
        if self.source_ids is not None and any(not value or len(value) > 100 for value in self.source_ids):
            raise ValueError("source_ids 中的文件 ID 不能为空或超过 100 字符。")
        return self


class FileResponseModel(FileInfo):
    request_id: str


class JobResponseModel(JobInfo):
    request_id: str


class SubmissionResponse(Submission):
    request_id: str


def create_app(settings: Settings | None = None, *, client: Client | None = None):
    settings = settings or (client.settings if client else Settings())
    sdk = client or Client(settings)

    @asynccontextmanager
    async def lifespan(app):
        await sdk.start()
        yield
        await sdk.aclose()

    # No HTML docs UI; OpenAPI JSON remains available to callers.
    app = FastAPI(title="Sirchmunk File Search", version=__version__, lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.client = sdk
    bearer = HTTPBearer(auto_error=False, scheme_name="ServiceToken")

    async def authenticate(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)):
        token = settings.service_token.get_secret_value()
        if not token:
            raise WrapError("SERVICE_NOT_CONFIGURED", "请通过 service_token 参数配置 HTTP 访问令牌。", 503)
        if credentials is None or not secrets.compare_digest(credentials.credentials.encode(), token.encode()):
            raise WrapError("UNAUTHORIZED", "缺少或无效的服务访问令牌。", 401)

    @app.middleware("http")
    async def request_id(request, call_next):
        request.state.request_id = "req_" + uuid.uuid4().hex
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        return response

    @app.exception_handler(WrapError)
    async def error_handler(request, error):
        return JSONResponse(status_code=error.status, content={
            "request_id": request.state.request_id,
            "error": {"code": error.code, "message": error.message},
        })

    @app.exception_handler(RequestValidationError)
    async def validation_handler(request, error):
        return JSONResponse(status_code=422, content={
            "request_id": request.state.request_id,
            "error": {"code": "INVALID_INPUT", "message": "请求字段不符合接口契约。"},
        })

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/openapi.json", dependencies=[Depends(authenticate)], include_in_schema=False)
    async def openapi():
        return app.openapi()

    @app.post("/v1/files", status_code=202, response_model=SubmissionResponse, dependencies=[Depends(authenticate)])
    async def submit(request: Request, file: UploadFile = File(...)):
        try:
            data = await file.read(settings.max_upload_mb * 1024**2 + 1)
            result = await sdk.submit_bytes(file.filename or "", data)
            return {"request_id": request.state.request_id, **result.model_dump()}
        finally:
            await file.close()

    @app.get("/v1/files/{source_id}", response_model=FileResponseModel, dependencies=[Depends(authenticate)])
    async def get_file(source_id: str, request: Request):
        return {"request_id": request.state.request_id, **sdk.get_file(source_id).model_dump()}

    @app.get("/v1/jobs/{job_id}", response_model=JobResponseModel, dependencies=[Depends(authenticate)])
    async def get_job(job_id: str, request: Request):
        return {"request_id": request.state.request_id, **sdk.get_job(job_id).model_dump()}

    @app.post("/v1/search", response_model=SearchResult, dependencies=[Depends(authenticate)])
    async def search(body: SearchRequest, request: Request):
        options = body.model_dump(exclude={"source_id", "source_ids", "query"})
        if body.source_ids is not None:
            result = await sdk.search_many(body.source_ids, body.query, **options)
        else:
            result = await sdk.search(body.source_id, body.query, **options)
        result.request_id = request.state.request_id
        return result

    @app.get("/v1/files/{source_id}/images/{image_id}", response_class=FileResponse,
             responses={200: {"content": {"image/png": {"schema": {"type": "string", "format": "binary"}},
                                           "image/jpeg": {"schema": {"type": "string", "format": "binary"}}}}},
             dependencies=[Depends(authenticate)])
    async def image(source_id: str, image_id: str):
        return FileResponse(sdk.image_path(source_id, image_id), media_type=sdk.image_mime_type(source_id, image_id),
                            headers={"Cache-Control": "private, no-store"})

    @app.delete("/v1/files/{source_id}", status_code=204, dependencies=[Depends(authenticate)])
    async def delete(source_id: str):
        await sdk.delete_source(source_id)

    return app

