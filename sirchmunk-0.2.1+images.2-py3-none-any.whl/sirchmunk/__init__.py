# Copyright (c) ModelScope Contributors. All rights reserved.
# Local modification, 2026-10-08: Lazy exports for native file/image retrieval.
from .search import AgenticSearch
from .version import __version__

__all__ = [
    "__version__",
    "AgenticSearch",
    "FileSearch",
    "FileSearchSettings",
    "FileSearchError",
    "search_file",
    "search_files",
]

# Lazy imports for agentic sub-modules
def __getattr__(name):
    if name in {"FileSearch", "FileSearchSettings", "FileSearchError", "search_file", "search_files"}:
        from . import multimodal
        return getattr(multimodal, name)
    if name == "ReActSearchAgent":
        from .agentic.react_agent import ReActSearchAgent
        return ReActSearchAgent
    if name == "DirectoryScanner":
        from .scan.dir_scanner import DirectoryScanner
        return DirectoryScanner
    if name == "SearchContext":
        from .schema.search_context import SearchContext
        return SearchContext
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
