import asyncio
import hashlib
import io
import json
import shutil
import time
import uuid
from contextlib import AsyncExitStack
from pathlib import Path
from loguru import logger
from PIL import Image
from .adapter import SirchmunkBackend
from .catalog import Catalog
from .image_store import ImageStore, cache_path
from .errors import WrapError
from .inspection import Inspector, SUPPORTED, EXTRACTOR_VERSION, normalized_png_bytes
from .models import (FileInfo, JobInfo, Submission, SearchResult, ImageResult,
                     ImageSource, VisionDescription, Evidence)
from .settings import Settings
from .vision import OpenAIVision, PROMPT_VERSION

_progress = logger.bind(file_image_processing=True)


class FileSearch:
    """Async SDK. Inject backend/vision for testing or additional providers.

    One Client/service process owns a data directory. Async context management
    cancels pending jobs safely, which are resumed when the directory reopens.
    Configuration keywords use explicit parameters/defaults only. Pass a
    FileSearchSettings object to opt into file/environment configuration.
    """

    def __init__(self, settings: Settings | None = None, *, backend=None, vision=None, **configuration):
        if settings is not None and configuration:
            raise TypeError("Pass either a settings object or configuration parameters, not both.")
        if configuration:
            settings = Settings.from_parameters(**configuration)
        self.settings = (settings or Settings()).resolve_storage_paths()
        self.catalog = Catalog(self.settings.data_dir)
        if self.settings.image_cache_dir.is_relative_to(self.catalog.root / "files"):
            raise WrapError("INVALID_STORAGE_PATH", "图片缓存目录必须位于原文件存储目录 files 之外。")
        self.image_store = ImageStore(self.settings.image_cache_dir)
        self.inspector = Inspector(self.settings)
        self.backend = backend or SirchmunkBackend(self.settings)
        self.vision = vision or OpenAIVision(self.settings)
        self.tasks = {}
        self.locks = {}
        self.ingest_limit = asyncio.Semaphore(self.settings.vision_concurrency)
        self.search_limit = asyncio.Semaphore(1)
        self.cache_lock = asyncio.Lock()
        self.submit_lock = asyncio.Lock()
        self.closed = False

    def _lock(self, source_id):
        return self.locks.setdefault(source_id, asyncio.Lock())

    async def _run_io(self, function, *args):
        task = asyncio.create_task(asyncio.to_thread(function, *args))
        try:
            return await asyncio.shield(task)
        except asyncio.CancelledError:
            # Do not remove staging files while an extraction thread still writes them.
            try:
                await task
            except Exception:
                pass
            raise

    def _fingerprint(self):
        # No secrets persisted. Provider/model/version changes invalidate recognition.
        return hashlib.sha256(json.dumps({
            "model": self.settings.vision_model, "url": self.settings.vision_base_url,
            "prompt": PROMPT_VERSION, "extractor": "file-extractor-v1",
        }, sort_keys=True).encode()).hexdigest()

    def _source_fingerprint(self):
        # Rebuild searchable context when extraction changes, retaining cached
        # descriptions of identical normalized images from the same model.
        return hashlib.sha256(f"{self._fingerprint()}:{EXTRACTOR_VERSION}".encode()).hexdigest()

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, *_):
        await self.aclose()

    async def start(self):
        # Upgrade existing catalogues or relocate images after a configured
        # cache-directory change, reusing descriptions without model calls.
        for record in self.catalog.all("sources"):
            if record["info"]["status"] == "ready" and record["images"]:
                if self._missing_image_assets(record):
                    source_id = record["info"]["source_id"]
                    if self.catalog.path(record["key"]).is_file():
                        self._queue_rebuild(record)
                    else:
                        _progress.warning(
                            "[图片缓存] {}：图片或描述缺失，且原文件也已丢失；"
                            "跳过此旧记录，重新提交该文件可恢复。", source_id)
                    continue
                await self._run_io(self._ensure_image_store, record)
        for job in self.catalog.all("jobs"):
            if job["status"] in {"pending", "processing"}:
                try:
                    self.catalog.source(job["source_id"])
                except WrapError:
                    continue
                self._schedule(job["job_id"])

    def _stored_image_path(self, image, *, vision=False):
        key = image["vision_key" if vision else "key"]
        if image.get("image_cache_root"):
            return cache_path(Path(image["image_cache_root"]), key)
        return self.catalog.path(key)  # Catalogue layout before image storage was separated.

    def _missing_image_assets(self, record):
        return any(
            not self.catalog.path(image["description_key"]).is_file()
            or not self._stored_image_path(image).is_file()
            or not self._stored_image_path(image, vision=True).is_file()
            for image in record["images"]
        )

    def _queue_rebuild(self, record):
        source_id = record["info"]["source_id"]
        job = self.catalog.get("jobs", record["job_id"])
        record["info"]["status"] = "pending"
        record["info"]["error"] = None
        job["status"] = "pending"
        job["error"] = None
        job["processed_images"] = 0
        self.catalog.put("sources", source_id, record)
        self.catalog.put("jobs", job["job_id"], job)
        _progress.info("[图片缓存] {}：图片或描述缺失，正在从原文件重建；已有描述缓存会继续复用。", source_id)

    def _ensure_image_store(self, record):
        root = str(self.image_store.root)
        if not all(image.get("image_cache_root") == root for image in record["images"]):
            source_id = record["info"]["source_id"]
            files = [self._stored_image_path(image, vision=vision)
                     for image in record["images"] for vision in (False, True)]
            self.image_store.install(source_id, files)
            for image in record["images"]:
                image["key"] = f"{source_id}/{Path(image['key']).name}"
                image["vision_key"] = f"{source_id}/{Path(image['vision_key']).name}"
                image["image_cache_root"] = root
            self.catalog.put("sources", source_id, record)
            _progress.info("[图片缓存] {}：已同步 {} 张图片到 {}，复用已有识别结果。",
                           source_id, len(record["images"]), self.image_store.root)
        self._compact_image_store(record)

    def _compact_image_store(self, record):
        """Make legacy original/vision pairs one original file per image."""
        source_id = record["info"]["source_id"]
        folder = self.image_store.path(source_id)
        changes = []
        for image in record["images"]:
            original = self._stored_image_path(image)
            vision = self._stored_image_path(image, vision=True)
            if original.parent != folder or vision.parent != folder or not original.is_file():
                raise WrapError("IMAGE_CACHE_MISSING", "缓存图片缺失或路径不属于当前文件。", 409)
            target = self.image_store.path(f"{source_id}/{image['image_id']}{original.suffix.lower()}")
            if original == target and vision == target:
                continue
            if target != original:
                if target.exists():
                    if hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(original.read_bytes()).digest():
                        raise WrapError("IMAGE_CACHE_CONFLICT", "图片编号文件与原图内容不一致。", 409)
                else:
                    shutil.copy2(original, target)
            changes.append((image, original, vision, target))
        if not changes:
            return
        for image, _, _, target in changes:
            image["key"] = image["vision_key"] = f"{source_id}/{target.name}"
            image["image_cache_root"] = str(self.image_store.root)
        self.catalog.put("sources", source_id, record)
        kept = {self._stored_image_path(image) for image in record["images"]}
        for _, original, vision, target in changes:
            for stale in (original, vision):
                if stale != target and stale not in kept:
                    stale.unlink(missing_ok=True)
        _progress.info("[图片缓存] {}：已按图片编号整理 {} 张原图，旧描述缓存继续复用。", source_id, len(changes))

    def _schedule(self, job_id):
        if job_id not in self.tasks or self.tasks[job_id].done():
            self.tasks[job_id] = asyncio.create_task(self._process(job_id))

    async def submit_file(self, file_path: str | Path):
        path = Path(file_path)
        if not path.is_file():
            raise WrapError("INVALID_INPUT", "输入文件不存在。")
        if path.stat().st_size > self.settings.max_upload_mb * 1024**2:
            raise WrapError("FILE_TOO_LARGE", "文件大小超出配置上限。", 413)
        return await self.submit_bytes(path.name, await asyncio.to_thread(path.read_bytes))

    async def submit_bytes(self, filename: str, data: bytes):
        if self.closed:
            raise WrapError("CLIENT_CLOSED", "SDK 已关闭。", 503)
        # Accept a display filename only; never use a remote name as a storage path.
        filename = filename.replace("\\", "/").rsplit("/", 1)[-1]
        if not filename or len(filename) > 250:
            raise WrapError("INVALID_INPUT", "文件名为空或过长。")
        suffix = Path(filename).suffix.lower()
        if suffix not in SUPPORTED:
            raise WrapError("UNSUPPORTED_MEDIA", "不支持该文件类型。", 415)
        if len(data) > self.settings.max_upload_mb * 1024**2:
            raise WrapError("FILE_TOO_LARGE", "文件大小超出配置上限。", 413)
        digest = hashlib.sha256(data).hexdigest()
        fingerprint = self._source_fingerprint()
        async with self.submit_lock:
            for old in self.catalog.all("sources"):
                if old["hash"] == digest and old["fingerprint"] == fingerprint and old["info"]["file_name"] == filename and old["info"]["status"] in {"pending", "processing", "ready"}:
                    if old["info"]["status"] == "ready":
                        original = self.catalog.path(old["key"])
                        if not original.is_file():
                            original.parent.mkdir(parents=True, exist_ok=True)
                            await asyncio.to_thread(original.write_bytes, data)
                            _progress.info("[文件缓存] {}：已从本次提交恢复缓存中的原文件。", old["info"]["source_id"])
                        if self._missing_image_assets(old):
                            self._queue_rebuild(old)
                    if old["info"]["status"] != "ready":
                        self._schedule(old["job_id"])
                        _progress.info("[文件处理] {} ({})：已在处理中，继续等待原任务。", filename, old["info"]["source_id"])
                    else:
                        _progress.info("[文件缓存] {} ({})：命中已处理文件，复用 {} 张图片，无需重新提取或识别。",
                                       filename, old["info"]["source_id"], len(old["images"]))
                    return Submission(source_id=old["info"]["source_id"], job_id=old["job_id"])
            source_id, job_id = "src_" + uuid.uuid4().hex, "job_" + uuid.uuid4().hex
            key = f"files/{source_id}/original{suffix}"
            path = self.catalog.path(key)
            path.parent.mkdir(parents=True, exist_ok=True)
            await asyncio.to_thread(path.write_bytes, data)
            info = FileInfo(source_id=source_id, file_name=filename, status="pending")
            self.catalog.submit(source_id, {
                "info": info.model_dump(), "key": key, "hash": digest,
                "fingerprint": fingerprint, "job_id": job_id, "images": [],
            }, job_id, JobInfo(job_id=job_id, source_id=source_id, status="pending").model_dump())
            self._schedule(job_id)
            return Submission(source_id=source_id, job_id=job_id)

    def get_file(self, source_id: str):
        return FileInfo.model_validate(self.catalog.source(source_id)["info"])

    def get_job(self, job_id: str):
        job = self.catalog.get("jobs", job_id)
        if not job:
            raise WrapError("JOB_NOT_FOUND", "任务不存在。", 404)
        self.catalog.source(job["source_id"])
        return JobInfo.model_validate(job)

    async def wait(self, job_id: str):
        job = self.get_job(job_id)
        if job.status in {"pending", "processing"}:
            self._schedule(job_id)
            await self.tasks[job_id]
        job = self.get_job(job_id)
        if job.status == "failed":
            raise WrapError(job.error["code"], job.error["message"], job.error.get("status", 400))
        return self.get_file(job.source_id)

    def _cache_id(self, path: Path):
        with Image.open(io.BytesIO(path.read_bytes())) as image:
            normalized = normalized_png_bytes(image)
        return hashlib.sha256(normalized).hexdigest() + ":" + self._fingerprint()

    async def _describe_cached(self, path: Path, *, label: str = ""):
        cache_id = self._cache_id(path)
        async with self.cache_lock:
            cached = self.catalog.get("cache", cache_id)
            if cached:
                _progress.info("[图片识别] {}：描述缓存命中，跳过视觉模型调用。", label or path.name)
                return VisionDescription.model_validate(cached)
            started = time.perf_counter()
            _progress.info("[图片识别] {}：正在调用视觉模型。", label or path.name)
            description = await self.vision.describe(path)
            description = VisionDescription.model_validate(description)
            self.catalog.put("cache", cache_id, description.model_dump())
            _progress.info("[图片识别] {}：识别完成并缓存，用时 {:.1f} 秒。", label or path.name, time.perf_counter() - started)
            return description

    async def _process(self, job_id: str):
        job = self.catalog.get("jobs", job_id)
        source_id = job["source_id"]
        async with self.ingest_limit, self._lock(source_id):
            record = self.catalog.source(source_id)
            if record["info"]["status"] == "ready":
                job["status"] = "completed"
                job["processed_images"] = job["total_images"] = len(record["images"])
                self.catalog.put("jobs", job_id, job)
                return
            info = FileInfo.model_validate(record["info"])
            started = time.perf_counter()
            _progress.info("[文件处理] {} ({})：开始检测内容并提取图片。", info.file_name, source_id)
            job["status"] = "processing"
            info.status = "processing"
            record["info"] = info.model_dump()
            self.catalog.put("sources", source_id, record)
            self.catalog.put("jobs", job_id, job)
            folder = self.catalog.path(f"files/{source_id}")
            for stale in folder.glob("staging_*"):
                self._remove(stale)
            stage = folder / ("staging_" + uuid.uuid4().hex)
            stage.mkdir()
            try:
                report = await self._run_io(self.inspector.inspect,
                    self.catalog.path(record["key"]), stage / "images", info.file_name)
                info.content_kind, info.has_images = report.content_kind, report.has_images
                info.image_count, info.detection_complete = len(report.images), report.complete
                info.warnings = list(dict.fromkeys(report.warnings))
                record["info"] = info.model_dump()
                self.catalog.put("sources", source_id, record)
                job["total_images"] = len(report.images)
                job["processed_images"] = 0
                self.catalog.put("jobs", job_id, job)
                _progress.info("[文件检测] {}：类型 {}，提取图片 {} 张。", source_id, info.content_kind, info.image_count)
                for warning in info.warnings:
                    _progress.warning("[文件检测] {}：{}", source_id, warning)
                if not report.images:
                    _progress.info("[图片处理] {}：没有可处理图片，跳过视觉识别。", source_id)
                search = stage / "search"
                search.mkdir()
                if report.text.strip():
                    (search / "document.txt").write_text(report.text, encoding="utf-8")
                images = []
                for index, image in enumerate(report.images, 1):
                    image_id = f"img_{index:04d}"
                    description = await self._describe_cached(image.path,
                        label=f"{source_id} {index}/{len(report.images)} {image_id}")
                    description_name = image_id + ".md"
                    location = ImageSource(source_id=source_id, file_name=info.file_name,
                        page=image.page, slide=image.slide, anchor=image.anchor)
                    (search / description_name).write_text(
                        f"Image: {image_id}\nSource: {info.file_name}\n"
                        f"Location: {location.model_dump_json()}\n"
                        f"Section: {image.section_title}\nSection text: {image.section_text}\n"
                        f"Caption: {description.caption}\nOCR: {description.ocr_text}\n"
                        f"Tags: {', '.join(description.tags)}\nContext: {image.context}\n",
                        encoding="utf-8")
                    images.append({"image_id": image_id, "caption": description.caption,
                        "cache_id": self._cache_id(image.path),
                        "key": f"files/{source_id}/ready/images/{(image.original_path or image.path).name}",
                        "vision_key": f"files/{source_id}/ready/images/{image.path.name}",
                        "mime_type": image.mime_type,
                        "description_key": f"files/{source_id}/ready/search/{description_name}",
                        "context": image.context, "section_id": image.section_id,
                        "section_title": image.section_title, "section_text": image.section_text,
                        "source": location.model_dump()})
                    job["processed_images"] = index
                    self.catalog.put("jobs", job_id, job)
                destination = folder / "ready"
                if images:
                    _progress.info("[图片存储] {}：保存 {} 张图片到缓存目录 {}。", source_id, len(images), self.image_store.root)
                    await self._run_io(self.image_store.install, source_id, list((stage / "images").iterdir()))
                    for image in images:
                        image["key"] = f"{source_id}/{Path(image['key']).name}"
                        image["vision_key"] = f"{source_id}/{Path(image['vision_key']).name}"
                        image["image_cache_root"] = str(self.image_store.root)
                    self._remove(stage / "images")
                if destination.exists():
                    self._remove(destination)
                stage.replace(destination)
                info.status = "ready"
                record["info"], record["images"] = info.model_dump(), images
                self.catalog.put("sources", source_id, record)
                job["status"] = "completed"
                self.catalog.put("jobs", job_id, job)
                _progress.info("[文件处理] {}：完成，图片 {}/{}，用时 {:.1f} 秒。",
                               source_id, job["processed_images"], job["total_images"], time.perf_counter() - started)
            except asyncio.CancelledError:
                info.status = "pending"
                record["info"] = info.model_dump()
                job["status"] = "pending"
                self.catalog.put("sources", source_id, record)
                self.catalog.put("jobs", job_id, job)
                _progress.warning("[文件处理] {}：任务中断，处理进度 {}/{}，保留缓存供恢复。",
                                  source_id, job.get("processed_images", 0), job.get("total_images", 0))
                raise
            except Exception as exc:
                error = exc if isinstance(exc, WrapError) else WrapError("INGEST_FAILED", "文件处理失败，请检查格式或模型输出。", 500)
                info.status = "failed"
                info.error = {"code": error.code, "message": error.message, "status": error.status}
                record["info"] = info.model_dump()
                job["status"], job["error"] = "failed", info.error
                self.catalog.put("sources", source_id, record)
                self.catalog.put("jobs", job_id, job)
                _progress.error("[文件处理] {}：失败（{}），{}", source_id, error.code, error.message)
            finally:
                if stage.exists():
                    self._remove(stage)

    def _remove(self, path: Path):
        target = path.resolve()
        if target == self.catalog.root or not target.is_relative_to(self.catalog.root):
            raise WrapError("INVALID_STORAGE_PATH", "拒绝删除受管目录之外的文件。")
        shutil.rmtree(target)

    async def search(self, source_id: str | list[str] | tuple[str, ...], query: str, *,
                     types=None, image_limit: int | None = None, verify_images=True):
        source_ids = [source_id] if isinstance(source_id, str) else source_id
        if not isinstance(source_ids, (list, tuple)) or not source_ids or any(
                not isinstance(value, str) or not value for value in source_ids):
            raise WrapError("INVALID_INPUT", "source_id 必须是文件 ID 或非空文件 ID 列表。")
        source_ids = list(dict.fromkeys(source_ids))
        types = ["text", "image"] if types is None else types
        if not query.strip() or len(query) > self.settings.max_query_chars:
            raise WrapError("INVALID_INPUT", "查询为空或长度超限。")
        if not types or any(t not in {"text", "image"} for t in types):
            raise WrapError("INVALID_INPUT", "types 必须包含 text 或 image。")
        if image_limit is not None and (type(image_limit) is not int or image_limit < 0):
            raise WrapError("INVALID_INPUT", "image_limit 必须为非负整数或 null（返回全部匹配图片）。")
        async with self.search_limit, AsyncExitStack() as stack:
            for source_id in sorted(source_ids):
                await stack.enter_async_context(self._lock(source_id))
            entries = []
            for source_id in source_ids:
                record = self.catalog.source(source_id)
                if record["info"]["status"] != "ready":
                    raise WrapError("SOURCE_NOT_READY", "文件尚未处理完成。", 409)
                entries.append((source_id, record, self.catalog.path(f"files/{source_id}/ready/search")))
            multiple = len(entries) > 1
            roots = [root for _, _, root in entries]

            def owner(path):
                return next(((source_id, record) for source_id, record, root in entries
                             if path.is_relative_to(root)), None)

            def image_key(source_id, image):
                return f"{source_id}:{image['image_id']}" if multiple else image["image_id"]

            def source_label(source_id, record, path):
                return f"{record['info']['file_name']} [{source_id}]/{path.name}" if multiple else ""

            work = self.catalog.path(f"files/{source_ids[0]}/work/{uuid.uuid4().hex}")
            work.mkdir(parents=True)
            try:
                include = ["document.txt"] if types == ["text"] else (["img_*.md"] if types == ["image"] else None)
                retrieval = await self.backend.search(query, roots if multiple else roots[0], work, include=include)
            finally:
                self._remove(work)
            warnings = list(dict.fromkeys(warning for _, record, _ in entries
                                          for warning in record["info"]["warnings"]))
            images, sources = [], []
            mapping = {self.catalog.path(image["description_key"]): (source_id, record, image)
                       for source_id, record, _ in entries for image in record["images"]}
            evidence_by_path = {path: evidence for evidence in retrieval.evidences
                                if (path := evidence.path.resolve()).is_file() and owner(path)}
            original_paths = {e.path.resolve() for e in retrieval.evidences}
            # Sirchmunk need not read every workflow image. Recall from all
            # selected files, using source-scoped IDs to avoid img_0001 clashes.
            if "image" in types and image_limit != 0 and mapping and hasattr(self.backend, "select_images"):
                candidates = []
                for source_id, record, _ in entries:
                    for image in record["images"]:
                        description = self.catalog.get("cache", image.get("cache_id", "")) or {}
                        candidates.append({key: image.get(key, "") for key in
                            ("caption", "context", "section_title", "section_text")}
                            | {"image_id": image_key(source_id, image),
                               "section_id": f"{source_id}:{image['section_id']}" if multiple and image.get("section_id") else image.get("section_id", ""),
                               "file_name": record["info"]["file_name"] if multiple else "",
                               "ocr_text": description.get("ocr_text", "")})
                recalled_ids = await self.backend.select_images(query, candidates)
                allowed_ids = {candidate["image_id"] for candidate in candidates}
                if not isinstance(recalled_ids, list) or any(not isinstance(value, str) or value not in allowed_ids for value in recalled_ids):
                    raise WrapError("INVALID_MODEL_OUTPUT", "图片筛选返回了当前文件以外的图片。", 502)
                chosen = set(recalled_ids)
            else:
                chosen = {image_key(source_id, image) for path, (source_id, _, image) in mapping.items()
                          if path in evidence_by_path}
            text_evidences = []
            for path, evidence in evidence_by_path.items():
                if path not in mapping:
                    source_id, record = owner(path)
                    text_evidences.append(Evidence(path, evidence.summary, source_label(source_id, record, path)))
            image_evidences = [Evidence(self.catalog.path(image["description_key"]), image["caption"],
                                       source_label(source_id, record, self.catalog.path(image["description_key"])))
                               for source_id, record, _ in entries for image in record["images"]
                               if image_key(source_id, image) in chosen]
            if image_limit is not None and image_limit > 0 and len(image_evidences) > image_limit and "image" in types:
                warnings.append(f"匹配图片候选超过 image_limit={image_limit}，返回结果可能未包含全部步骤图。")
            selected = set()
            accepted = []
            for evidence in text_evidences + image_evidences:
                path = evidence.path.resolve()
                if not owner(path) or not path.is_file() or path in selected:
                    continue
                selected.add(path)
                image_entry = mapping.get(path)
                if image_entry:
                    source_id, _, image = image_entry
                    if "image" not in types or (image_limit is not None and len(images) >= image_limit):
                        continue
                    status = "unverified"
                    if verify_images:
                        if hasattr(self.vision, "verify_with_context"):
                            verified = await self.vision.verify_with_context(
                                self._stored_image_path(image, vision=True), query,
                                context={key: image.get(key, "") for key in
                                    ("section_title", "section_text", "context", "caption")})
                        else:
                            verified = await self.vision.verify(self._stored_image_path(image, vision=True), query)
                        if not verified.relevant:
                            continue
                        status = "verified"
                    images.append(ImageResult(image_id=image["image_id"],
                        reference_id=f"{source_id}:{image['image_id']}", caption=image["caption"],
                        path=str(self._stored_image_path(image)),
                        mime_type=image["mime_type"],
                        url=f"/v1/files/{source_id}/images/{image['image_id']}",
                        verification_status=status, source=ImageSource.model_validate(image["source"])))
                    sources.append({"source_id": source_id, "type": "image", "image_id": image["image_id"]})
                    accepted.append(evidence)
                elif "text" in types:
                    source_id, record = owner(path)
                    sources.append({"source_id": source_id, "type": "text", "file_name": record["info"]["file_name"]})
                    accepted.append(evidence)
            # Upstream answers may cite staged filesystem paths; replace known citations.
            answer = retrieval.answer
            if {e.path.resolve() for e in accepted} != original_paths:
                if not accepted:
                    answer = "未找到与查询相关的证据。"
                elif hasattr(self.backend, "synthesize"):
                    answer = await self.backend.synthesize(query, accepted)
                else:
                    raise WrapError("BACKEND_INCOMPATIBLE", "自定义检索适配器需提供 synthesize 方法以重建筛选后的答案。", 500)
            for source_id, record, root in entries:
                label = record["info"]["file_name"]
                if multiple:
                    label += f" [{source_id}]"
                for path in root.iterdir():
                    answer = answer.replace(str(path), label)
                    answer = answer.replace(path.as_posix(), label)
            if multiple and len({image.image_id for image in images}) != len(images):
                warnings.append("多个文件包含相同的 img_编号，请使用 images[].reference_id 区分对应图片。")
            return SearchResult(request_id="req_" + uuid.uuid4().hex, answer=answer,
                                images=images, sources=sources, warnings=warnings)

    async def search_file(self, file_path, query, **kwargs):
        """Search one or more paths; a scalar selects one file, a list selects many."""
        file_paths = file_path
        if isinstance(file_paths, (str, Path)):
            file_paths = [file_paths]
        if not isinstance(file_paths, (list, tuple)) or not file_paths or any(
                not isinstance(path, (str, Path)) for path in file_paths):
            raise WrapError("INVALID_INPUT", "file_path 必须是文件路径或非空文件路径列表。")
        submitted = [await self.submit_file(path) for path in file_paths]
        jobs = {item.job_id for item in submitted}
        await asyncio.gather(*(self.wait(job_id) for job_id in jobs))
        return await self.search([item.source_id for item in submitted], query, **kwargs)

    def image_path(self, source_id: str, image_id: str):
        record = self.catalog.source(source_id)
        if record["info"]["status"] != "ready":
            raise WrapError("SOURCE_NOT_READY", "文件尚未处理完成。", 409)
        for image in record["images"]:
            if image["image_id"] == image_id:
                return self._stored_image_path(image)
        raise WrapError("IMAGE_NOT_FOUND", "图片不存在或不属于该文件。", 404)

    def read_image(self, source_id: str, image_id: str):
        return self.image_path(source_id, image_id).read_bytes()

    def image_mime_type(self, source_id: str, image_id: str):
        record = self.catalog.source(source_id)
        for image in record["images"]:
            if image["image_id"] == image_id:
                return image["mime_type"]
        raise WrapError("IMAGE_NOT_FOUND", "图片不存在或不属于该文件。", 404)

    async def delete_source(self, source_id: str):
        record = self.catalog.source(source_id)
        task = self.tasks.get(record["job_id"])
        if task and not task.done():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        async with self._lock(source_id):
            record = self.catalog.source(source_id)
            record["info"]["status"] = "deleted"
            self.catalog.put("sources", source_id, record)
            async with self.cache_lock:
                referenced = {image["cache_id"] for other in self.catalog.all("sources")
                    if other["info"]["status"] != "deleted" for image in other.get("images", []) if "cache_id" in image}
                for image in record["images"]:
                    if image.get("cache_id") and image["cache_id"] not in referenced:
                        self.catalog.delete("cache", image["cache_id"])
            job = self.catalog.get("jobs", record["job_id"])
            if job["status"] != "completed":
                job["status"] = "cancelled"
                self.catalog.put("jobs", job["job_id"], job)
            folder = self.catalog.path(f"files/{source_id}")
            if folder.exists():
                self._remove(folder)
            self.image_store.delete_source(source_id)

    async def aclose(self):
        self.closed = True
        for task in self.tasks.values():
            if not task.done():
                task.cancel()
        await asyncio.gather(*self.tasks.values(), return_exceptions=True)
        try:
            if hasattr(self.backend, "aclose"):
                await self.backend.aclose()
        finally:
            if hasattr(self.vision, "aclose"):
                await self.vision.aclose()



# Compatibility name for the former wrapper SDK.
Client = FileSearch


async def search_file(
    file_path: str | Path | list[str | Path] | tuple[str | Path, ...], query: str, *,
    base_url: str, model: str, api_key: str = "",
    vision_base_url: str | None = None, vision_model: str | None = None,
    vision_api_key: str | None = None,
    data_dir: str | Path | None = None, image_cache_dir: str | Path | None = None,
    image_limit: int | None = None, verify_images: bool = True, types=None,
    **configuration,
) -> SearchResult:
    """Search one file or a list of files without loading environment config.

    Vision uses the text provider/model unless explicitly overridden. Models
    must support images when the input contains images. Cache paths and model
    timeouts can be provided as configuration arguments. Reuse FileSearch for
    multiple queries in a service; this helper opens/closes a client per call.
    """
    if data_dir is not None:
        configuration["data_dir"] = data_dir
    if image_cache_dir is not None:
        configuration["image_cache_dir"] = image_cache_dir
    vision_url = base_url if vision_base_url is None else vision_base_url
    if vision_api_key is None:
        vision_api_key = api_key if vision_url == base_url else ""
    async with FileSearch(
        text_base_url=base_url, text_api_key=api_key, text_model=model,
        vision_base_url=vision_url, vision_api_key=vision_api_key,
        vision_model=model if vision_model is None else vision_model,
        **configuration,
    ) as client:
        return await client.search_file(file_path, query, types=types,
                                        image_limit=image_limit, verify_images=verify_images)
