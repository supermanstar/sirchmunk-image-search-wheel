"""Native file and image retrieval with persistent image caching.

Install ``sirchmunk[images]`` to use this optional capability.
"""
from .sdk import FileSearch, search_file
from .settings import FileSearchSettings
from .models import FileInfo, SearchResult
from .errors import FileSearchError

__all__ = ["FileSearch", "FileSearchSettings", "FileSearchError", "FileInfo", "SearchResult", "search_file"]
